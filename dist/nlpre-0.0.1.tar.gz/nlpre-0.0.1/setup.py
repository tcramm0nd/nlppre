from distutils.core import setup
import setuptools

setup(name='nlpre',
      version='0.0.1',
      author='Tim Crammond',
      author_email='25987791+tcramm0nd@users.noreply.github.com',
      url='https://github.com/tcramm0nd/nlpre',
      description= 'A NLP Text Processing tool',
      packages=setuptools.find_packages()
      )
